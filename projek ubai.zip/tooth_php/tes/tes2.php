<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beranda Layanan Kesehatan</title>
    <style>

/* Global Styles */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    color: #333;
}

/* Header Styles */
header {
    background-color:  #aebafe;
    padding: 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

header .logo h1 {
    color: white;
    font-size: 34px;
}

nav ul {
    list-style-type: none;
    display: flex;
}

nav ul li {
    margin-left: 20px;
}

nav ul li a {
    color: white;
    text-decoration: none;
    font-size: 16px;
}

nav ul li a:hover {
    color: #836747;
        }


/* Hero Section */
.hero {
    background-color: #001061;
    color: white;
    padding: 80px 20px;
    text-align: center;
}

.hero h2 {
    font-size: 32px;
    margin-bottom: 20px;
}

.hero p {
    font-size: 18px;
    margin-bottom: 30px;
}

.cta-buttons a {
    background-color: #ff5722;
    color: white;
    padding: 12px 20px;
    text-decoration: none;
    margin: 0 10px;
    border-radius: 5px;
    font-size: 16px;
}

.cta-buttons a:hover {
    background-color: #e64a19;
}

/* Service Cards */
.services {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    gap: 20px;
    padding: 20px;
    background-color: #fff;
}

.service-card {
    background-color: #fafafa;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    padding: 20px;
    text-align: center;
}

.service-card img {
    width: 100%;
    height: auto;
    border-radius: 8px;
}

.service-card h3 {
    font-size: 20px;
    margin-top: 15px;
}

.service-card p {
    font-size: 14px;
    margin-top: 10px;
}

.service-btn {
    display: inline-block;
    background-color: #008cba;
    color: white;
    padding: 10px 15px;
    text-decoration: none;
    border-radius: 5px;
    margin-top: 15px;
}

.service-btn:hover {
    background-color: #0077b5;
}

/* Footer */
footer {
    background-color: #333;
    color: white;
    padding: 20px;
    text-align: center;
}

footer .social-links a {
    color: white;
    margin: 0 10px;
    text-decoration: none;
}

footer .social-links a:hover {
    text-decoration: underline;
}

/* Media Queries for Responsiveness */
@media (max-width: 768px) {
    .hero h2 {
        font-size: 28px;
    }

    .hero p {
        font-size: 16px;
    }

    .cta-buttons a {
        font-size: 14px;
        padding: 10px 15px;
    }

    .service-card {
        padding: 15px;
    }

    .service-card h3 {
        font-size: 18px;
    }

    .service-card p {
        font-size: 12px;
    }

    .service-btn {
        font-size: 14px;
        padding: 8px 12px;
    }
}


    </style>
</head>
<body>

    <!-- Header -->
    <header>
        <div class="logo">
        <h1><img src="ayam-removebg-preview.png" width="90" right="90" />Toothcare </h1>
        </div>
        <nav>
            <ul>
                <li><a href="#">Beranda</a></li>
                <li><a href="#">Tentang Kami</a></li>
                <li><a href="#">Layanan</a></li>
                <li><a href="#">Kontak</a></li>
            </ul>
        </nav>
    </header>

    <!-- Hero Section -->
    <section class="hero">
        <div class="hero-text">
            <h2>Selamat datang, <?= htmlspecialchars($_SESSION['username']); ?>!</h2>
            <p>Temukan layanan kesehatan yang Anda butuhkan dengan mudah. Belanja obat, tentukan jadwal pemeriksaan, dan baca artikel kesehatan terbaru.</p>
            <div class="cta-buttons">
                <a href="#" class="cta-btn">Jelajahi Layanan</a>
                <a href="#" class="cta-btn">Tentukan Jadwal</a>
            </div>
        </div>
    </section>

    <!-- Layanan Kesehatan -->
    <section class="services">
        <h2></h2>
        <div class="service-card">
            <img src="https://via.placeholder.com/150" alt="Toko Obat">
            <h3>Toko Obat</h3>
            <p>Beli obat-obatan Anda secara online dengan harga terjangkau. Pengiriman cepat.</p>
            <a href="#" class="service-btn">Lihat Produk</a>
        </div>
        <div class="service-card">
            <img src="https://via.placeholder.com/150" alt="Tentukan Jadwal">
            <h3>Tentukan Jadwal</h3>
            <p>Jadwalkan kunjungan ke dokter atau layanan kesehatan sesuai kebutuhan Anda.</p>
            <a href="#" class="service-btn">Buat Jadwal</a>
        </div>
        <div class="service-card">
            <img src="https://via.placeholder.com/150" alt="Artikel Kesehatan">
            <h3>Artikel Kesehatan</h3>
            <p>Baca artikel kesehatan terkini untuk mendapatkan informasi terbaru mengenai kesehatan Anda.</p>
            <a href="#" class="service-btn">Baca Artikel</a>
        </div>
        <div class="service-card">
            <img src="https://via.placeholder.com/150" alt="Konsultasi Online">
            <h3>Konsultasi Online</h3>
            <p>Konsultasi secara online dengan dokter ahli melalui chat atau video call.</p>
            <a href="#" class="service-btn">Mulai Konsultasi</a>
        </div>
        <div class="service-card">
            <img src="https://via.placeholder.com/150" alt="Layanan Darurat">
            <h3>Layanan Darurat</h3>
            <p>Panggil layanan darurat kapan saja untuk situasi medis yang membutuhkan bantuan segera.</p>
            <a href="#" class="service-btn">Panggil Darurat</a>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <p>&copy; 2024 Layanan Kesehatan Kami. Semua Hak Dilindungi.</p>
        <div class="social-links">
            <a href="#">Facebook</a>
            <a href="#">Instagram</a>
            <a href="#">Twitter</a>
        </div>
    </footer>

</body>
</html>
<div><h2>Selamat datang, <?= htmlspecialchars($_SESSION['username']); ?>!</h2></div>