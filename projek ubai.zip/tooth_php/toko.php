

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Toko</title>
</head>
<style>

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    color: #333;
}

/* Header Styles */
header {
    background-color:  #aebafe;
    padding: 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

header .logo h1 {
    color: white;
    font-size: 34px;
}

nav ul {
    list-style-type: none;
    display: flex;
}

nav ul li {
    margin-left: 20px;
}

nav ul li a {
    color: white;
    text-decoration: none;
    font-size: 16px;
}

nav ul li a:hover {
    color: #836747;
        }
        .best-sellers {
    padding: 40px 20px;
    background-color: #fff;
}

.best-sellers h2 {
    font-size: 24px;
    margin-bottom: 20px;
    text-align: center;
}

/* Grid yang bisa digulir horizontal */
.product-grid {
    display: flex;
    overflow-x: auto; /* Memungkinkan scrolling horizontal */
    gap: 20px;
    padding-bottom: 20px;
}

.product-card {
    background-color: #fff;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    text-align: center;
    min-width: 250px; /* Menentukan lebar minimum setiap card */
    flex-shrink: 0; /* Menghindari shrink */
}

.product-card img {
    width: 100%;
    height: 150px;
    object-fit: cover;
    border-radius: 10px;
    margin-bottom: 10px;
}

.product-card h3 {
    font-size: 18px;
    margin-bottom: 10px;
}

.product-card p {
    font-size: 16px;
    color: #333;
    margin-bottom: 15px;
}

.product-card .btn {
    background-color: #2d98da;
    color: white;
    padding: 10px 15px;
    text-decoration: none;
    border-radius: 5px;
    transition: background-color 0.3s;
}

.product-card .btn:hover {
    background-color: #1d6fa5;
}
/* Footer */
footer {
    background-color: #333;
    color: white;
    padding: 20px;
    text-align: center;
}

footer .social-links a {
    color: white;
    margin: 0 10px;
    text-decoration: none;
}

footer .social-links a:hover {
    text-decoration: underline;
}

</style>

<body>
<header>
        <div class="logo">
        <h1><img src="ayam-removebg-preview.png" width="90" right="90" />Toothcare </h1>
        </div>
        <nav>
            <ul>
                <li><a href="beranda.php">Beranda</a></li>
                <li><a href="toko.php">Toko Kami</a></li>
                <li><a href="jadwal.php">jadwal pemriksaan</a></li>
                <li><a href="history.php">History</a></li>
                <li><a href="#">lougout</a></li>
            </ul>
        </nav>
    </header>


    <section class="best-sellers">
        <h2>Obat Terlaris</h2>
        <div class="product-grid">
            <div class="product-card">
                <img src="c.jpg" alt="Obat Batuk">
                <h3>Obat Batuk</h3>
                <p>Harga: Rp 50.000</p>
                <a href="jadwal.php" class="btn">beli</a>
            </div>
        
            <div class="product-card">
                <img src="d.png" alt="Obat Flu">
                <h3>Obat Flu</h3>
                <p>Harga: Rp 40.000</p>
                <a href="jadwal.php" class="btn">beli</a>
            </div>
            <div class="product-card">
                <img src="a.jpg" alt="Obat Pilek">
                <h3>Obat Pilek</h3>
                <p>Harga: Rp 30.000</p>
                <a href="jadwal.php" class="btn">beli</a>
            </div>
            <!-- Tambahkan lebih banyak produk jika diperlukan -->
            <div class="product-card">
                <img src="b.jpg" alt="Obat Asam Urat">
                <h3>Obat Asam Urat</h3>
                <p>Harga: Rp 60.000</p>
                <a href="jadwal.php" class="btn">beli</a>
            </div>
            <div class="product-card">
                <img src="e.jpg" alt="Obat Vitamin">
                <h3>Obat Vitamin</h3>
                <p>Harga: Rp 80.000</p>
                <a href="jadwal.php" class="btn">beli</a>
            </div>
            <div class="product-card">
                <img src="f.jpg" alt="Obat Cacing">
                <h3>Obat Cacing</h3>
                <p>Harga: Rp 25.000</p>
                <a href="jadwal.php" class="btn">beli</a>
            </div>
</div>
    
           
        </div>
    </div>
</section>

<section class="best-sellers">
        <div class="product-grid">
            <div class="product-card">
                <img src="g.jpg" alt="Obat Batuk">
                <h3>Obat sakit gigi</h3>
                <p>Harga: Rp 50.000</p>
                <a href="jadwal.php" class="btn">beli</a>
            </div>
            <div class="product-card">
                <img src="h.jpg" alt="Obat Flu">
                <h3>Obat gusi</h3>
                <p>Harga: Rp 40.000</p>
                <a href="jadwal.php" class="btn">beli</a>
            </div>
            <div class="product-card">
                <img src="j.png" alt="Obat Pilek">
                <h3>antibiotik</h3>
                <p>Harga: Rp 30.000</p>
                <a href="jadwal.php" class="btn">beli</a>
            </div>
            <!-- Tambahkan lebih banyak produk jika diperlukan -->
            <div class="product-card">
                <img src="k.jpg" alt="Obat Asam Urat">
                <h3>odol herbal</h3>
                <p>Harga: Rp 60.000</p>
                <a href="jadwal.php" class="btn">beli</a>
            </div>
            <div class="product-card">
                <img src="l.jpg" alt="Obat Vitamin">
                <h3>Obat Vitamin</h3>
                <p>Harga: Rp 80.000</p>
                <a href="jadwal.php" class="btn">beli</a>
            </div>
            <div class="product-card">
                <img src="z.png" alt="Obat Cacing">
                <h3>Obat diare</h3>
                <p>Harga: Rp 25.000</p>
                <a href="jadwal.php" class="btn">beli</a>
            </div>
</div>
    
           
        </div>
    </div>
</section>
<!-- Footer -->
<footer>
        <p>&copy; 2024 Layanan Kesehatan Kami. Semua Hak Dilindungi.</p>
    </footer>

</body>
</html>