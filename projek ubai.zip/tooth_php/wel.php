
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Welcome to Toothcare</title>
    <style>
        body {
            margin: 0;
        padding: 0;
        font-family: Arial, sans-serif;
        background-image: url(lauttan.jpg);
        background-size: cover;
        background-position: 0%;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
    }
.container {
    text-align: center;
    margin-top: 50px; /* Adjust this value to move text lower or higher */
}

.welcome-text {
    font-size: 4rem;
    font-weight: bold;
    background: url(laut.jpg) no-repeat center center;
    background-size: cover;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    color: transparent;
    margin-bottom: 30px;          
}

.buttons {
    display: flex;
    justify-content: center;
}

.button {
    text-decoration: none;
    background-color:  mintcream;          
    color: aquamarine;                      
    padding: 15px 30px;             
  margin: 0 10px;                    
    border-radius: 5px;                
    transition: background-color 0.3s;   
}

.button:hover {
    background-color: black;          
}

    </style>
</head>
<body>
    <br>
    <br>
    <div class="container">
        <h1 class="welcome-text">Welcome to Toothcare</h1>
        <div class="buttons">
            <a href="login.php" class="button">Login</a>
            <a href="register.php" class="button">Register</a>
        </div>
    </div>
</body>
</html>
