

<!DOCTYPE html>
<html lang="id">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    
    <title>Halaman Login</title>
    <style>
      /* Reset dasar */
      body {
        margin: 0;
        padding: 0;
        font-family: Arial, sans-serif;
        background-image: url("danauu.png");
        background-size: cover;
        background-position: 0%;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
      }

      .login-container {
        background-image: url("danauu.png");
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        width: 300px;
        text-align: center;
        color: ivory;
      }

      h1 {
        margin-bottom: 20px;
        color: ivory;
      }

      .form-group {
        margin-bottom: 15px;
        text-align: left;
      }

      label {
        display: block;
        margin-bottom: 5px;
        font-weight: bold;
      }

      input[type="username"],
      input[type="password"] {
        width: 100%;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
      }

      .btn-next {
    display: inline-block;
    padding: 15px 30px;
    font-size: 16px;
    font-weight: bold;
    color: black;
    background-color: white;
    text-align: center;
    text-decoration: none;
    border-radius: 10px; /* Membuat sudut kotak lebih membulat */
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    transition: background-color 0.3s, transform 0.3s;
}

.btn-next:hover {
    background-color: #FFCC4C; /* Warna saat hover */
    transform: translateY(-2px); /* Efek naik sedikit */
}

.btn-next:active {
    transform: translateY(2px); /* Efek saat tombol diklik */
}

      .error {
        color: red;
        font-size: 0.875em;
        display: block;
        margin-top: 5px;
      }

      #message {
        margin-top: 20px;
        font-size: 1.125em;
        color: green;
      }
    </style>
  </head>
  <body>
    <div class="login-container">
      <h1><img src="ayam-removebg-preview.png" width="190" right="190" /> Toothcare </h1>
      <form method= "POST" action="">
      <div class="form-group">
          <label for="username">username</label>
          <input type="username" name="username" placeholder="Username" required />
        </div>
        <div class="form-group">
          <label for="password">Password:</label>
          <input type="password" name="password" placeholder="Password" required />
        </div>
        <a href="beranda.php" class="btn-next">Login</a>

      </form>
    </div>
    </body>
</html>


#FFCC4C