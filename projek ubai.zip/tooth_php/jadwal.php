<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>jadwal</title>
</head>
<style>
    * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
        margin: 0;
        padding: 0;
        font-family: Arial, sans-serif;
        background-image: url("lauttan.jpg");
        background-size: cover;
        background-position: 0%;
        align-items: center;
        height: 100vh;
      }

/* Header Styles */
header {
    background-color:  #aebafe;
    padding: 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

header .logo h1 {
    color: white;
    font-size: 34px;
}

nav ul {
    list-style-type: none;
    display: flex;
}

nav ul li {
    margin-left: 20px;
}

nav ul li a {
    color: white;
    text-decoration: none;
    font-size: 16px;
}

nav ul li a:hover {
    color: #836747;
        }

        .container {
            width: 80%;
            margin: 0 auto;
            background-image: url("lauttan.jpg");
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }
        h2 {
            text-align: center;
            color: white;
        }
        label {
            display: block;
            margin: 10px 0 5px;
            color: white;
        }
        input, select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
        }
        button {
            background-color: #83daff;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            width: 100%;
        }
        button:hover {
            background-color: #ff4b3f;
        }

        /* Footer */
footer {
    background-color: #333;
    color: white;
    padding: 20px;
    text-align: center;
    margin-top: 150px;
}

footer .social-links a {
    color: white;
    margin: 0 10px;
    text-decoration: none;
}

footer .social-links a:hover {
    text-decoration: underline;
}

</style>
<body>
<header>
        <div class="logo">
        <h1><img src="ayam-removebg-preview.png" width="90" right="90" />Toothcare </h1>
        </div>
        <nav>
            <ul>
                <li><a href="beranda.php">Beranda</a></li>
                <li><a href="toko.php">Toko Kami</a></li>
                <li><a href="jadwal.php">jadwal pemriksaan</a></li>
                <li><a href="history.php">History</a></li>
                <li><a href="#">lougout</a></li>
            </ul>
        </nav>
    </header>


    <div class="container">
        <h2>Silakan Pilih Jadwal</h2>
               <form action="" method="POST" enctype="multipart/form-data">
           <label for="dokter">Pilih Dokter</label>
            <select  required="dokter" name="dokter" required>
                <option value="">-- Pilih Dokter --</option>
                <option value="Dr. Agus Pratama">Dr. Agus Pratama</option>
                <option value="Dr. Bella Hartati">Dr. Bella Hartati</option>
                <option value="Dr. Charles Wibowo">Dr. Charles Wibowo</option>
            </select>
            <label for="obat">Pilih obat</label>
            <select  required="obat" name="obat" required>
                <option value="">-- obat --</option>
                <option value="obat batuk">obat batuk</option>
                <option value="obat gusi">obat gusi</option>
                <option value="obat gigi">obat gigi</option>
                <option value="obat flu">obat flu</option>
                <option value="obat cacing">obat cacing</option>
                <option value="obat pilek">obat pilek</option>
                <option value="obat asam urat">asam urat</option>
                <option value="obat vitamin">obat vitamin</option>
                <option value="antibiotik">antibiotik</option>
                <option value="obat diare">obat diare</option>
            </select>

            <label for="tanggal">Pilih Tanggal</label>
            <input type="date" required="tanggal" name="tanggal" required>

            <label for="waktu">Pilih Waktu</label>
            <select  required="waktu" name="waktu" required>
                <option value="">-- Pilih Waktu --</option>
                <option value="09:00- 10:00">09:00 - 10:00</option>
                <option value="10:00- 11:00">10:00 - 11:00</option>
                <option value="13:00 - 14:00">13:00 - 14:00</option>
                <option value="14:00- 15:00">14:00 - 15:00</option>
            </select>

            <button name="submit" type="submit" value="submit"  >Buat Janji Temu</button>
            
        </form>
    </div>

    <!-- Footer -->
<footer>
        <p>&copy; 2024 Layanan Kesehatan Kami. Semua Hak Dilindungi.</p>
    </footer>
</body>
</html>
<?php
// panggil koneksi database
include "koneksidb.php";
// uji jika tombol simpan diklik
if (isset($_POST['submit'])) {
    $simpan = mysqli_query($conn, "INSERT INTO berhasil (dokter, obat, tanggal,waktu) VALUES
    ('$_POST[dokter]','$_POST[obat]','$_POST[tanggal]','$_POST[waktu]')");

    // jika simpan sukses
    if ($simpan) {
        echo "<script> alert ('Berhasil Simpan Registrasi')</script>";
        echo "<script> window.location.href='jadwal.php'</script>";
    } else {
        echo "<script> alert ('Gagal Simpan Registrasi')</script>";
        echo "<script> window.location.href='jadwal.php'</script>";
    }
} 
?>