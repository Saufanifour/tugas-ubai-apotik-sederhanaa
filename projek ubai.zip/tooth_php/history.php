'
    
    <?php
    include "koneksidb.php"
    ?>
    
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>history</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    </head>
    <style>
        * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        color: #333;
    }

    /* Header Styles */
    header {
        background-color:  #aebafe;
        padding: 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    header .logo h1 {
        color: white;
        font-size: 34px;
    }

    nav ul {
        list-style-type: none;
        display: flex;
    }

    nav ul li {
        margin-left: 20px;
    }

    nav ul li a {
        color: white;
        text-decoration: none;
        font-size: 16px;
    }

    nav ul li a:hover {
        color: #836747;
            }

    </style>
    <body>
    <header>
            <div class="logo">
            <h1><img src="ayam-removebg-preview.png" width="90" right="90" />Toothcare </h1>
            </div>
            <nav>
                <ul>
                    <li><a href="beranda.php">Beranda</a></li>
                    <li><a href="toko.php">Toko Kami</a></li>
                    <li><a href="jadwal.php">jadwal pemriksaan</a></li>
                    <li><a href="history.php">History</a></li>
                    <li><a href="#">lougout</a></li>
                </ul>
            </nav>
        </header>
        <div class="container">
    <table align="table responsive" class="table table-striped table-bordered table-hover">
        <tr>
            <th class="text-center">No</th>
            <th class="text-center">Nama dokter</th>
            <th class="text-center">obat</th>
            <th class="text-center">tanggal</th>
            <th class="text-center">jam temu</th>
        </tr>
        <?php
        $no =1;
        $tampil = mysqli_query($conn,"SELECT * FROM berhasil");
        while($data = mysqli_fetch_array($tampil)):
        ?>
        <tr>
            <td class="text-center"><?= $no++?></td>
            <td class="text-center"><?= $data['dokter']?></td>
            <td class="text-center"><?= $data['obat']?></td>
            <td class="text-center"><?= $data['tanggal']?></td>
            <td class="text-center"><?= $data['waktu']?></td>
            <td class="text-center">
        </tr>
        
        <div class="modal fade" id="hapus<?=$no ?>"data-bs-backdrop="static"data-bs-keyboard="false" tabindex="-1"aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title text-black" id="staticBackdropLabel" >konfirmasi</h5>
                    </div>
                    <form method="post" action="hapus.php">
                                <input type="hidden" name="Nama" value="<?= $data['Nama'] ?>">
                                <div class="modal-body">
                                    <h5 class="text-center text-black">Apakah anda yakin akan hapus data ini? <br>
                                        <span class="text-danger"><?= $data['Nama'] ?> - <?= $data['Telp'] ?></span>></span>
                                    </h5>
                                </div>
                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-primary" name="bhapus">Hapus</button>
                                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Batal</button>
                                </div>
                            </form>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
    </table>
    </body>
    </html>
    